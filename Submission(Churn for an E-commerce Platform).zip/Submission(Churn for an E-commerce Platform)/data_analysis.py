# Import required libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score

# Load the dataset
data = pd.read_csv('data/events.csv')

# Display the first few rows of the dataset
print(data.head())

# Show dataset info (e.g., data types, missing values)
print(data.info())

# Get descriptive statistics (summary of numerical columns)
print(data.describe())

# Convert event_time to datetime
data['event_time'] = pd.to_datetime(data['event_time'])

# Check for missing values and fill or drop them
print(data.isnull().sum())

# Handle missing values if necessary (e.g., fill with the mean or drop rows)
# data['price'] = data['price'].fillna(data['price'].mean())  # Example of filling missing values
# data.dropna(inplace=True)  # Alternatively, you can drop rows with missing values

# Feature Engineering: Recency, Frequency, Monetary (RFM)
# Recency: Time since the user's last purchase
data['last_purchase'] = data[data['event_type'] == 'purchase'].groupby('user_id')['event_time'].transform('max')
recency = (data['last_purchase'].max() - data['last_purchase']).dt.days

# Frequency: Number of purchases made by each user
frequency = data[data['event_type'] == 'purchase'].groupby('user_id').size()

# Monetary: Total amount spent by each user
monetary = data[data['event_type'] == 'purchase'].groupby('user_id')['price'].sum()

# Merge the features back into a single dataframe
user_features = pd.DataFrame({
    'recency': recency,
    'frequency': frequency,
    'monetary': monetary
})

print(user_features.head())

# Define Churn: If no purchase in the last 30 days, the user is considered churned
churn_threshold = 30
user_features['churn'] = user_features['recency'] > churn_threshold

# Split the data into training and testing sets
X = user_features.drop(columns='churn')
y = user_features['churn']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Train a Random Forest classifier
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Predict on the test set
y_pred = model.predict(X_test)

# Evaluate the model
print("Classification Report:")
print(classification_report(y_test, y_pred))

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:")
print(cm)

# AUC Score
print("AUC Score:", roc_auc_score(y_test, y_pred))

# Plot Feature Importance
feature_importance = model.feature_importances_
features = X.columns

plt.barh(features, feature_importance)
plt.xlabel('Feature Importance')
plt.ylabel('Features')
plt.title('Feature Importance for Churn Prediction')
plt.show()

# Business Recommendations based on model results:
# Example insights:
# 1. Users with high recency but low frequency may be targeted with personalized offers to increase purchase frequency.
# 2. Users with high recency but no purchase in the last 30 days can be re-engaged with tailored discounts or reminders.

