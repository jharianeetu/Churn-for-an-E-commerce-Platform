import joblib
import matplotlib.pyplot as plt
import numpy as np

# Load the saved model
model = joblib.load('churn_model.pkl')

# Feature importance visualization
feature_importances = model.feature_importances_
features = ['recency', 'frequency', 'monetary']  # Adjust as per your feature names

# Plot feature importances
plt.figure(figsize=(8, 6))
plt.barh(features, feature_importances, color='skyblue')
plt.xlabel('Importance')
plt.title('Feature Importance')
plt.show()
