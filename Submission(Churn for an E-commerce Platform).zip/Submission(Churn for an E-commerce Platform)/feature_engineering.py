import pandas as pd

# Load the dataset
data = pd.read_csv('data/events.csv')

# Check column names
print("Columns in the dataset:", data.columns)

# Convert 'event_time' to datetime format
data['event_time'] = pd.to_datetime(data['event_time'], errors='coerce')

# Check for missing values in 'event_time'
missing_event_time = data['event_time'].isnull().sum()
if missing_event_time > 0:
    print(f"Warning: {missing_event_time} rows have invalid event_time values and will be dropped.")
    data = data.dropna(subset=['event_time'])

# Feature Engineering: RFM Metrics
rfm = data.groupby('user_id').agg(
    recency=('event_time', lambda x: (x.max() - x.min()).days if x.notnull().all() else None),
    frequency=('event_type', 'count'),
    monetary=('price', 'sum')
)

# Reset index for easier usage later
rfm.reset_index(inplace=True)

# Save processed features to a CSV file
rfm.to_csv('user_features.csv', index=False)
print("Feature engineering completed. Features saved to 'user_features.csv'.")
